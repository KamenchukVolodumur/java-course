package pl.mini.logs;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.zip.GZIPOutputStream;

import static java.nio.charset.StandardCharsets.UTF_8;

/** Creates the same sample directory as Main. */
final class SampleLogs {
    private SampleLogs() { }

    static Path create(Path dir) throws IOException {
        Files.writeString(dir.resolve("app.log"), """
                2025-03-14T10:00:00 INFO [auth] user anna logged in
                2025-03-14T10:00:05 WARN [db] slow query 1200ms
                garbage line
                2025-03-14T10:01:00 ERROR [db] connection lost
                2025-03-14T10:02:00 ERROR [auth] invalid token
                2025-03-14T10:03:00 ERROR [db] connection lost
                """);
        Files.createDirectories(dir.resolve("old"));
        writeGz(dir.resolve("old/app-2025-03-13.log.gz"),
                "2025-03-13T23:59:00 INFO [auth] user bob logged out\n"
                        + "2025-03-13T23:59:30 ERROR [cache] eviction failed\n");
        Files.writeString(dir.resolve("notes.txt"), "not a log");
        return dir;
    }

    static void writeGz(Path file, String text) throws IOException {
        try (var out = new PrintWriter(new OutputStreamWriter(new GZIPOutputStream(Files.newOutputStream(file)), UTF_8))) {
            out.print(text);
        }
    }
}
