package pl.mini.logs;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static java.nio.charset.StandardCharsets.UTF_8;
import static java.nio.file.StandardOpenOption.APPEND;
import static org.junit.jupiter.api.Assertions.*;

class LogsTest {

    @TempDir
    Path dir;

    // ===== STAGE 1 =====

    @Test
    @Tag("stage1")
    void invalidDateGivesEmptyResult() {
        assertEquals(Optional.empty(), LogParser.parse("2025-13-45T99:00:00 INFO [x] y"));
    }

    @Test
    @Tag("stage1")
    void messageMayContainBracketsAndSpaces() {
        LogEntry e = LogParser.parse("2025-03-14T10:00:00 DEBUG [http-client] GET [/a b] 200").orElseThrow();
        assertEquals(Level.DEBUG, e.level());
        assertEquals("http-client", e.component());
        assertEquals("GET [/a b] 200", e.message());
        assertEquals(LocalDateTime.of(2025, 3, 14, 10, 0), e.time());
    }

    @Test
    @Tag("stage1")
    void lowercaseLevelIsNotALevel() {
        assertEquals(Optional.empty(), LogParser.parse("2025-03-14T10:00:00 info [x] y"));
    }

    // ===== STAGE 2 =====

    @Test
    @Tag("stage2")
    void blankLinesAreNotMalformed() throws IOException {
        Path f = dir.resolve("a.log");
        Files.writeString(f, "\n2025-03-14T10:00:00 INFO [a] x\n   \n");
        LogStats s = LogAnalyzer.analyze(f);
        assertEquals(0, s.malformed());
        assertEquals(1, s.files());
    }

    @Test
    @Tag("stage2")
    void gzFilesAreRead() throws IOException {
        Path f = dir.resolve("a.log.gz");
        SampleLogs.writeGz(f, "2025-03-14T10:00:00 ERROR [x] y\n");
        assertEquals(Map.of(Level.ERROR, 1L), LogAnalyzer.analyze(f).counts());
    }

    @Test
    @Tag("stage2")
    void emptyFileHasNoTimes() throws IOException {
        Path f = dir.resolve("empty.log");
        Files.writeString(f, "");
        LogStats s = LogAnalyzer.analyze(f);
        assertNull(s.first());
        assertNull(s.last());
        assertEquals(Optional.empty(), s.topErrorComponent());
    }

    @Test
    @Tag("stage2")
    void statsAreImmutableCopies() {
        Map<Level, Long> counts = new HashMap<>(Map.of(Level.INFO, 1L));
        LogStats s = new LogStats(counts, 0, null, null, new HashMap<>(), 1);
        counts.put(Level.ERROR, 5L);
        assertEquals(Map.of(Level.INFO, 1L), s.counts());
        assertThrows(UnsupportedOperationException.class, () -> s.counts().put(Level.WARN, 1L));
        assertThrows(UnsupportedOperationException.class, () -> s.errorsByComponent().put("x", 1L));
    }

    @Test
    @Tag("stage2")
    void topErrorComponentBreaksTiesAlphabetically() {
        LogStats s = new LogStats(Map.of(), 0, null, null, Map.of("zeta", 2L, "alpha", 2L, "mid", 1L), 1);
        assertEquals(Optional.of("alpha"), s.topErrorComponent());
    }

    @Test
    @Tag("stage2")
    void countsAreInLevelDeclarationOrder() {
        LogStats s = new LogStats(Map.of(Level.ERROR, 1L, Level.TRACE, 2L, Level.INFO, 3L), 0, null, null, Map.of(), 1);
        assertEquals(List.of(Level.TRACE, Level.INFO, Level.ERROR), List.copyOf(s.counts().keySet()));
    }

    // ===== STAGE 3 =====

    @Test
    @Tag("stage3")
    void mergeHandlesNullTimes() {
        LocalDateTime t1 = LocalDateTime.of(2025, 1, 1, 0, 0), t2 = LocalDateTime.of(2025, 1, 2, 0, 0);
        LogStats a = new LogStats(Map.of(Level.INFO, 1L), 1, t2, t2, Map.of(), 1);
        LogStats b = new LogStats(Map.of(Level.INFO, 2L, Level.WARN, 1L), 2, t1, t1, Map.of("x", 1L), 1);

        LogStats m = LogStats.empty().merge(a).merge(b);
        assertEquals(Map.of(Level.INFO, 3L, Level.WARN, 1L), m.counts());
        assertEquals(3, m.malformed());
        assertEquals(t1, m.first());
        assertEquals(t2, m.last());
        assertEquals(2, m.files());
        assertEquals(Map.of("x", 1L), m.errorsByComponent());
    }

    @Test
    @Tag("stage3")
    void brokenGzipIsSkippedWithAWarning() throws IOException {
        SampleLogs.create(dir);
        Files.write(dir.resolve("broken.log.gz"), "not gzip at all".getBytes(UTF_8));
        LogStats all = DirectoryAnalyzer.analyzeAll(dir);
        assertEquals(2, all.files());
    }

    // ===== STAGE 4 =====

    @Test
    @Tag("stage4")
    void unzipExtractsSafeEntries() throws IOException {
        SampleLogs.create(dir);
        ReportWriter.writeCsv(DirectoryAnalyzer.analyzeAll(dir), dir.resolve("report.csv"));
        Path zip = dir.resolve("archive.zip");
        ReportWriter.archive(dir, zip);

        Path out = dir.resolve("out");
        ReportWriter.unzip(zip, out);
        assertEquals(Files.readString(dir.resolve("app.log")), Files.readString(out.resolve("app.log")));
        assertTrue(Files.exists(out.resolve("old/app-2025-03-13.log.gz")));
        assertFalse(Files.exists(out.resolve("notes.txt")));
    }

    @Test
    @Tag("stage4")
    void csvUsesUnixLineBreaks() throws IOException {
        Path out = dir.resolve("r.csv");
        ReportWriter.writeCsv(new LogStats(Map.of(Level.WARN, 2L), 0, null, null, Map.of(), 1), out);
        assertEquals("level,count\nWARN,2\n", Files.readString(out));
    }

    // ===== STAGE 5 =====

    @Test
    @Tag("stage5")
    void positionIsCountedInBytes() throws IOException {
        Path log = dir.resolve("u.log");
        Files.writeString(log, "2025-03-14T10:00:00 INFO [ui] привіт 👋\n");
        LogWatcher w = new LogWatcher(dir);
        List<String> messages = new ArrayList<>();
        w.addListener((f, e) -> messages.add(e.message()));

        Files.writeString(log, "2025-03-14T10:00:01 INFO [ui] ще раз\n", APPEND);
        w.poll();
        assertEquals(List.of("ще раз"), messages);
    }

    @Test
    @Tag("stage5")
    void subdirectoriesAndGzAreNotWatched() throws IOException {
        LogWatcher w = new LogWatcher(dir);
        List<String> seen = new ArrayList<>();
        w.addListener((f, e) -> seen.add(f.getFileName().toString()));
        Files.createDirectories(dir.resolve("sub"));
        Files.writeString(dir.resolve("sub/x.log"), "2025-03-14T10:00:00 INFO [a] b\n");
        SampleLogs.writeGz(dir.resolve("y.log.gz"), "2025-03-14T10:00:00 INFO [a] b\n");
        w.poll();
        assertEquals(List.of(), seen);
    }

    @Test
    @Tag("stage5")
    void failingListenerDoesNotStopOthers() throws IOException {
        LogWatcher w = new LogWatcher(dir);
        List<String> seen = new ArrayList<>();
        w.addListener((f, e) -> { throw new IllegalStateException("broken listener"); });
        w.addListener((f, e) -> seen.add(e.message()));
        Files.writeString(dir.resolve("a.log"), "2025-03-14T10:00:00 INFO [a] ok\n");
        w.poll();
        assertEquals(List.of("ok"), seen);
    }

    @Test
    @Tag("stage5")
    void listenerMayUnsubscribeDuringDispatch() throws IOException {
        LogWatcher w = new LogWatcher(dir);
        List<String> seen = new ArrayList<>();
        LogListener[] self = new LogListener[1];
        self[0] = (f, e) -> { seen.add(e.message()); w.removeListener(self[0]); };
        w.addListener(self[0]);
        Files.writeString(dir.resolve("a.log"), "2025-03-14T10:00:00 INFO [a] one\n2025-03-14T10:00:01 INFO [a] two\n");
        w.poll();
        assertEquals(List.of("one"), seen);
    }
}
