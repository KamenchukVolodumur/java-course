package pl.mini.logs;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import static java.nio.charset.StandardCharsets.UTF_8;
import static java.nio.file.StandardOpenOption.APPEND;
import static pl.mini.testkit.Console.assertPrints;

/** Runs the same code as the STAGE blocks in Main and compares the output with the task. */
class MainOutputTest {

    @TempDir
    Path dir;

    @Test
    @Tag("stage1")
    void stage1() {
        assertPrints("""
                Optional[LogEntry[time=2025-03-14T10:00, level=INFO, component=auth, message=user anna logged in]]
                Optional.empty
                Optional.empty
                """, () -> {
            System.out.println(LogParser.parse("2025-03-14T10:00:00 INFO [auth] user anna logged in"));
            System.out.println(LogParser.parse("garbage line"));
            System.out.println(LogParser.parse("2025-03-14T10:00:00 FATAL [x] y"));
        });
    }

    @Test
    @Tag("stage2")
    void stage2() throws IOException {
        SampleLogs.create(dir);
        assertPrints("""
                {INFO=1, WARN=1, ERROR=3} malformed=1
                2025-03-14T10:00 2025-03-14T10:03 Optional[db]
                """, () -> {
            LogStats s = LogAnalyzer.analyze(dir.resolve("app.log"));
            System.out.println(s.counts() + " malformed=" + s.malformed());
            System.out.println(s.first() + " " + s.last() + " " + s.topErrorComponent());
        });
    }

    @Test
    @Tag("stage3")
    void stage3() throws IOException {
        SampleLogs.create(dir);
        assertPrints("""
                {INFO=2, WARN=1, ERROR=4} files=2
                2025-03-13T23:59 2025-03-14T10:03 {auth=1, cache=1, db=2}
                """, () -> {
            LogStats all = DirectoryAnalyzer.analyzeAll(dir);
            System.out.println(all.counts() + " files=" + all.files());
            System.out.println(all.first() + " " + all.last() + " " + all.errorsByComponent());
        });
    }

    @Test
    @Tag("stage4")
    void stage4() throws IOException {
        SampleLogs.create(dir);
        assertPrints("""
                level,count
                INFO,2
                WARN,1
                ERROR,4
                app.log
                old/app-2025-03-13.log.gz
                report.csv
                OK: небезпечний запис в архіві: ../escaped.txt
                """, () -> {
            LogStats all = DirectoryAnalyzer.analyzeAll(dir);
            Path report = dir.resolve("report.csv");
            ReportWriter.writeCsv(all, report);
            System.out.print(Files.readString(report));
            Path zip = dir.resolve("archive.zip");
            ReportWriter.archive(dir, zip);
            try (var zf = new ZipFile(zip.toFile())) {
                zf.stream().map(ZipEntry::getName).sorted().forEach(System.out::println);
            }
            Path evil = dir.resolve("evil.zip");
            try (var zos = new ZipOutputStream(Files.newOutputStream(evil))) {
                zos.putNextEntry(new ZipEntry("../escaped.txt"));
                zos.write("boom".getBytes(UTF_8));
                zos.closeEntry();
            }
            try { ReportWriter.unzip(evil, dir.resolve("unpacked")); }
            catch (IOException e) { System.out.println("OK: " + e.getMessage()); }
        });
    }

    @Test
    @Tag("stage5")
    void stage5() throws IOException {
        SampleLogs.create(dir);
        assertPrints("""
                []
                ALERT new.log: crash
                [app.log:INFO, new.log:ERROR]
                ALERT new.log: crash again
                2
                """, () -> {
            LogWatcher w = new LogWatcher(dir);
            List<String> seen = new ArrayList<>();
            LogListener collector = (file, e) -> seen.add(file.getFileName() + ":" + e.level());
            w.addListener(collector);
            w.poll();
            System.out.println(seen);
            Files.writeString(dir.resolve("app.log"), "2025-03-14T11:00:00 INFO [api] started\n", APPEND);
            Files.writeString(dir.resolve("new.log"), "2025-03-14T11:00:01 ERROR [api] crash\n");
            w.addListener((f, e) -> {
                if (e.level() == Level.ERROR) System.out.println("ALERT " + f.getFileName() + ": " + e.message());
            });
            w.poll();
            System.out.println(seen);
            w.removeListener(collector);
            Files.writeString(dir.resolve("new.log"), "2025-03-14T11:00:02 ERROR [api] crash again\n", APPEND);
            Files.writeString(dir.resolve("new.log"), "2025-03-14T11:00:03 INFO [api] half", APPEND);
            w.poll();
            System.out.println(seen.size());
        });
    }
}
