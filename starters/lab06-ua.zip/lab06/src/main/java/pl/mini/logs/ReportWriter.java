package pl.mini.logs;

import java.io.IOException;
import java.nio.file.Path;

// STAGE 4
public final class ReportWriter {
    private ReportWriter() { }

    public static void writeCsv(LogStats stats, Path out) throws IOException {
        throw new UnsupportedOperationException("TODO");
    }

    public static void archive(Path dir, Path zipFile) throws IOException {
        throw new UnsupportedOperationException("TODO");
    }

    public static void unzip(Path zipFile, Path targetDir) throws IOException {
        throw new UnsupportedOperationException("TODO");
    }
}
