package pl.mini.logs;

import java.io.IOException;
import java.nio.file.Path;

// STAGE 3
public final class DirectoryAnalyzer {
    private DirectoryAnalyzer() { }

    public static LogStats analyzeAll(Path dir) throws IOException {
        throw new UnsupportedOperationException("TODO");
    }
}
