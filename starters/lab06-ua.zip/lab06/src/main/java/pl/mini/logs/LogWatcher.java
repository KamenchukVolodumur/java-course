package pl.mini.logs;

import java.io.IOException;
import java.nio.file.Path;

// STAGE 5
public class LogWatcher {

    public LogWatcher(Path dir) throws IOException {
        throw new UnsupportedOperationException("TODO");
    }

    public void addListener(LogListener l) {
        throw new UnsupportedOperationException("TODO");
    }

    public void removeListener(LogListener l) {
        throw new UnsupportedOperationException("TODO");
    }

    public void poll() throws IOException {
        throw new UnsupportedOperationException("TODO");
    }
}
