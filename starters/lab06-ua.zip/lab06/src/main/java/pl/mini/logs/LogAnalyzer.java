package pl.mini.logs;

import java.io.IOException;
import java.nio.file.Path;

// STAGE 2
public final class LogAnalyzer {
    private LogAnalyzer() { }

    public static LogStats analyze(Path file) throws IOException {
        throw new UnsupportedOperationException("TODO");
    }
}
