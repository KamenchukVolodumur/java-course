package pl.mini.logs;

import java.nio.file.Path;

@FunctionalInterface
public interface LogListener {
    void onEntry(Path file, LogEntry entry);
}
