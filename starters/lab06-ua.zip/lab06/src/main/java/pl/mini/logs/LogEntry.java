package pl.mini.logs;

import java.time.LocalDateTime;

public record LogEntry(LocalDateTime time, Level level, String component, String message) { }
