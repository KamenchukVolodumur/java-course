package pl.mini.logs;

public enum Level { TRACE, DEBUG, INFO, WARN, ERROR }
