package pl.mini.logs;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.Optional;

// STAGE 2 (merge — STAGE 3)
public record LogStats(Map<Level, Long> counts,
                       long malformed,
                       LocalDateTime first, LocalDateTime last,
                       Map<String, Long> errorsByComponent,
                       int files) {

    // TODO: a compact constructor with defensive, unmodifiable copies of both maps

    public Optional<String> topErrorComponent() {
        throw new UnsupportedOperationException("TODO");
    }

    public LogStats merge(LogStats other) {
        throw new UnsupportedOperationException("TODO");
    }

    public static LogStats empty() {
        throw new UnsupportedOperationException("TODO");
    }
}
