package pl.mini.logs;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import static java.nio.charset.StandardCharsets.UTF_8;
import static java.nio.file.StandardOpenOption.APPEND;

public class Main {
    public static void main(String[] args) throws IOException {
        Path dir = Files.createTempDirectory("lab06");
        Files.writeString(dir.resolve("app.log"), """
                2025-03-14T10:00:00 INFO [auth] user anna logged in
                2025-03-14T10:00:05 WARN [db] slow query 1200ms
                garbage line
                2025-03-14T10:01:00 ERROR [db] connection lost
                2025-03-14T10:02:00 ERROR [auth] invalid token
                2025-03-14T10:03:00 ERROR [db] connection lost
                """);
        Files.createDirectories(dir.resolve("old"));
        try (var out = new PrintWriter(new OutputStreamWriter(new GZIPOutputStream(
                Files.newOutputStream(dir.resolve("old/app-2025-03-13.log.gz"))), UTF_8))) {
            out.print("2025-03-13T23:59:00 INFO [auth] user bob logged out\n");
            out.print("2025-03-13T23:59:30 ERROR [cache] eviction failed\n");
        }
        Files.writeString(dir.resolve("notes.txt"), "not a log");

        // ===== STAGE 1 =====
        // System.out.println(LogParser.parse("2025-03-14T10:00:00 INFO [auth] user anna logged in"));
        // System.out.println(LogParser.parse("garbage line"));
        // System.out.println(LogParser.parse("2025-03-14T10:00:00 FATAL [x] y"));

        // ===== STAGE 2 =====
        // LogStats s = LogAnalyzer.analyze(dir.resolve("app.log"));
        // System.out.println(s.counts() + " malformed=" + s.malformed());
        // System.out.println(s.first() + " " + s.last() + " " + s.topErrorComponent());

        // ===== STAGE 3 =====
        // LogStats all = DirectoryAnalyzer.analyzeAll(dir);
        // System.out.println(all.counts() + " files=" + all.files());
        // System.out.println(all.first() + " " + all.last() + " " + all.errorsByComponent());

        // ===== STAGE 4 =====
        // Path report = dir.resolve("report.csv");
        // ReportWriter.writeCsv(all, report);
        // System.out.print(Files.readString(report));
        // Path zip = dir.resolve("archive.zip");
        // ReportWriter.archive(dir, zip);
        // try (var zf = new ZipFile(zip.toFile())) {
        //     zf.stream().map(ZipEntry::getName).sorted().forEach(System.out::println);
        // }
        // Path evil = dir.resolve("evil.zip");
        // try (var zos = new ZipOutputStream(Files.newOutputStream(evil))) {
        //     zos.putNextEntry(new ZipEntry("../escaped.txt"));
        //     zos.write("boom".getBytes(UTF_8));
        //     zos.closeEntry();
        // }
        // try { ReportWriter.unzip(evil, dir.resolve("unpacked")); }
        // catch (IOException e) { System.out.println("OK: " + e.getMessage()); }

        // ===== STAGE 5 =====
        // LogWatcher w = new LogWatcher(dir);
        // List<String> seen = new ArrayList<>();
        // LogListener collector = (file, e) -> seen.add(file.getFileName() + ":" + e.level());
        // w.addListener(collector);
        // w.poll();
        // System.out.println(seen);
        // Files.writeString(dir.resolve("app.log"), "2025-03-14T11:00:00 INFO [api] started\n", APPEND);
        // Files.writeString(dir.resolve("new.log"), "2025-03-14T11:00:01 ERROR [api] crash\n");
        // w.addListener((f, e) -> {
        //     if (e.level() == Level.ERROR) System.out.println("ALERT " + f.getFileName() + ": " + e.message());
        // });
        // w.poll();
        // System.out.println(seen);
        // w.removeListener(collector);
        // Files.writeString(dir.resolve("new.log"), "2025-03-14T11:00:02 ERROR [api] crash again\n", APPEND);
        // Files.writeString(dir.resolve("new.log"), "2025-03-14T11:00:03 INFO [api] half", APPEND);
        // w.poll();
        // System.out.println(seen.size());
    }
}
