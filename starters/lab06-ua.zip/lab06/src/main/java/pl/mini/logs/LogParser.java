package pl.mini.logs;

import java.util.Optional;

// STAGE 1
public final class LogParser {
    private LogParser() { }

    public static Optional<LogEntry> parse(String line) {
        throw new UnsupportedOperationException("TODO");
    }
}
