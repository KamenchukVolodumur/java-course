# Лабораторна 12: Production-ready бекенд

Ця лабораторна продовжує **ваш** код лабораторної 10, тому тут лише нове: `pom.xml` з усіма залежностями, заготовка `AppConfig` з тестами і приклад `.env`.

## Що всередині

| Файл | Статус |
| --- | --- |
| `pom.xml` | надано: замінює `pom.xml` лабораторної 10 (PostgreSQL, HikariCP, Jackson, Testcontainers, fat-JAR `target/app.jar`) |
| `.env.example` | скопіюйте в `.env` і заповніть; `.env` не комітьте |
| `config/AppConfig` | **ваше**: замініть кожен `throw new UnsupportedOperationException("TODO")` |
| `config/AppConfigTest` | тести до етапів |

## Як відкрити

IntelliJ IDEA: **File → Open** → оберіть цю папку (ту, де лежить `pom.xml`). JDK 21 або новіший.

## Тести

```bash
./mvnw test                         # усі етапи
./mvnw test -Dgroups=stage1         # лише один етап: stage1
```

Етапи, які ви ще не почали, падають з `UnsupportedOperationException: TODO` — так і має бути. Етап готовий, коли його тести зелені і програма друкує рівно очікуваний вивід із завдання.

## Як почати

1. Скопіюйте `src/` вашої лабораторної 10 у цю папку (файли звідси не перезаписуйте).
2. У `pom.xml` властивість `main.class` має вказувати на ваш клас із `main` (за замовчуванням `pl.mini.bank.App`).
3. `./mvnw test` має бути зеленим, крім `AppConfigTest`, поки ви не реалізуєте етап 1.

Тести етапів 2–5 (HTTP API, MDC, Testcontainers, Docker) ви пишете самі, як вимагає завдання. Для `*IT` з Testcontainers потрібен запущений Docker: `./mvnw verify`.
