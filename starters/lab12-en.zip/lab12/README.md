# Lab 12: A Production-Ready Backend

This lab continues **your** code from lab 10, so only the new parts are here: `pom.xml` with all the dependencies, an `AppConfig` stub with tests and a sample `.env`.

## What is inside

| File | Status |
| --- | --- |
| `pom.xml` | given: replaces the lab 10 `pom.xml` (PostgreSQL, HikariCP, Jackson, Testcontainers, a fat JAR `target/app.jar`) |
| `.env.example` | copy to `.env` and fill in; do not commit `.env` |
| `config/AppConfig` | **yours**: replace every `throw new UnsupportedOperationException("TODO")` |
| `config/AppConfigTest` | tests for the stages |

## Opening the project

IntelliJ IDEA: **File → Open** → select this folder (the one with `pom.xml`). JDK 21 or newer.

## Tests

```bash
./mvnw test                         # all stages
./mvnw test -Dgroups=stage1         # only one stage: stage1
```

Stages you have not started yet fail with `UnsupportedOperationException: TODO` — that is expected. A stage is done when its tests are green and the program prints exactly the expected output from the task.

## Getting started

1. Copy `src/` of your lab 10 into this folder (do not overwrite the files from here).
2. In `pom.xml` the `main.class` property must point to your class with `main` (`pl.mini.bank.App` by default).
3. `./mvnw test` must be green, except `AppConfigTest` until you implement stage 1.

You write the tests of stages 2–5 (HTTP API, MDC, Testcontainers, Docker) yourself, as the task requires. The `*IT` tests with Testcontainers need a running Docker: `./mvnw verify`.
