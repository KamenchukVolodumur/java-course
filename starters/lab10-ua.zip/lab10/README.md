# Лабораторна 10: Шарова архітектура, JDBC і Mockito

Текст завдання — на сайті курсу. У цьому проєкті є все, що інакше довелося б копіювати звідти.

## Що всередині

| Файл | Статус |
| --- | --- |
| `schema.sql`, `logback.xml`, `Client`, `ClientRepository`, `*Exception` | надано, не змінюйте |
| `Pesel`, `Database`, `JdbcClientRepository`, `ClientService` | **ваше**: замініть кожен `throw new UnsupportedOperationException("TODO")` |
| `ClientServiceTest` | **ваше**: тести на Mockito (етап 5), перший уже написано |
| `src/test/java/...` | тести до етапів |

## Як відкрити

IntelliJ IDEA: **File → Open** → оберіть цю папку (ту, де лежить `pom.xml`). JDK 17 або новіший.

## Тести

```bash
./mvnw test                         # усі етапи
./mvnw test -Dgroups=stage1         # лише один етап: stage1, stage2, stage3, stage4, stage5
./mvnw test -Dgroups=stage1,stage2  # кілька етапів
```

Етапи, які ви ще не почали, падають з `UnsupportedOperationException: TODO` — так і має бути. Етап готовий, коли його тести зелені і програма друкує рівно очікуваний вивід із завдання.

> Інтеграційні тести (`*IT`, база H2) запускає `./mvnw verify`, а не `./mvnw test`: `./mvnw verify -Dgroups=stage3`. Модульні тести (`*Test`) — `./mvnw test`.
>
> Етап 5 — це **ваші** тести в `ClientServiceTest`: чотири з них поки що падають з `TODO`. Код цієї лабораторної знадобиться в лабораторній 12.
