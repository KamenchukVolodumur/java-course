# Лабораторна 11: Патерни проєктування — система замовлень

Текст завдання — на сайті курсу. У цьому проєкті є все, що інакше довелося б копіювати звідти.

## Що всередині

| Файл | Статус |
| --- | --- |
| `Main.java` | надано: розкоментовуйте блоки `STAGE` по черзі |
| `Customer`, `CustomerType`, `DiscountPolicy`, `Discount`, `OrderPlaced`, `OrderCancelled`, `Priced`, `OrderRequest` | надано, не змінюйте |
| `OrderItem`, `Order`, `DiscountFactory`, `OrderEvents`, `Inventory`, `Analytics`, `BasePrice`, `GiftWrap`, `Insurance`, `Shipping`, `Receipt`, `OrderService` | **ваше**: замініть кожен `throw new UnsupportedOperationException("TODO")` |
| `src/test/java/...` | тести до етапів |

## Як відкрити

IntelliJ IDEA: **File → Open** → оберіть цю папку (ту, де лежить `pom.xml`). JDK 17 або новіший.

## Запуск

```bash
./mvnw compile exec:java -Dexec.mainClass=pl.mini.shop.Main
```

На Windows замість `./mvnw` — `mvnw.cmd`. Встановлювати Maven не потрібно: wrapper завантажить його під час першого запуску. В IntelliJ можна просто натиснути ▶ біля `main`.

## Тести

```bash
./mvnw test                         # усі етапи
./mvnw test -Dgroups=stage1         # лише один етап: stage1, stage2, stage3, stage4, stage5
./mvnw test -Dgroups=stage1,stage2  # кілька етапів
```

Етапи, які ви ще не почали, падають з `UnsupportedOperationException: TODO` — так і має бути. Етап готовий, коли його тести зелені і програма друкує рівно очікуваний вивід із завдання.

> Політики знижок (`student`, `vip`, `bulk`, промокоди) реалізуйте самі: лямбдами або маленькими класами в пакеті `discount`.
