# Лабораторна 08: Біржовий стакан

Текст завдання — на сайті курсу. У цьому проєкті є все, що інакше довелося б копіювати звідти.

## Що всередині

| Файл | Статус |
| --- | --- |
| `Main.java` | надано: розкоментовуйте блоки `STAGE` по черзі |
| `Side`, `Trade` | надано, не змінюйте |
| `Order`, `BookSnapshot`, `Counters`, `OrderBook`, `Simulation`, `RiskService` | **ваше**: замініть кожен `throw new UnsupportedOperationException("TODO")` |
| `src/test/java/...` | тести до етапів |

## Як відкрити

IntelliJ IDEA: **File → Open** → оберіть цю папку (ту, де лежить `pom.xml`). JDK 21 або новіший.

## Запуск

```bash
./mvnw compile exec:java -Dexec.mainClass=pl.mini.exchange.Main
```

На Windows замість `./mvnw` — `mvnw.cmd`. Встановлювати Maven не потрібно: wrapper завантажить його під час першого запуску. В IntelliJ можна просто натиснути ▶ біля `main`.

## Тести

```bash
./mvnw test                         # усі етапи
./mvnw test -Dgroups=stage1         # лише один етап: stage1, stage2, stage3, stage4, stage5
./mvnw test -Dgroups=stage1,stage2  # кілька етапів
```

Етапи, які ви ще не почали, падають з `UnsupportedOperationException: TODO` — так і має бути. Етап готовий, коли його тести зелені і програма друкує рівно очікуваний вивід із завдання.

> Проєкт налаштовано на Java 21 (віртуальні потоки в етапі 5). На Java 17 змініть `maven.compiler.release` у `pom.xml` на 17 і в `Main` замініть `newVirtualThreadPerTaskExecutor()` на `newCachedThreadPool()`.
>
> Тести на гонки ловлять помилки з великою ймовірністю, але не гарантовано: зелений тест — не доказ потокобезпечності.
