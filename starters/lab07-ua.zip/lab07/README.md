# Лабораторна 07: Анотації та рефлексія

Текст завдання — на сайті курсу. У цьому проєкті є все, що інакше довелося б копіювати звідти.

## Що всередині

| Файл | Статус |
| --- | --- |
| `Main.java` | надано: розкоментовуйте блоки `STAGE` по черзі |
| `plugins/Plugin` | надано, не змінюйте |
| `testing/*`, `json/*`, `plugins/PluginInfo`, `plugins/PluginRegistry`, `proxy/*` | **ваше**: замініть кожен `throw new UnsupportedOperationException("TODO")` |
| `src/test/java/...` | тести до етапів |

## Як відкрити

IntelliJ IDEA: **File → Open** → оберіть цю папку (ту, де лежить `pom.xml`). JDK 17 або новіший.

## Запуск

```bash
./mvnw compile exec:java -Dexec.mainClass=pl.mini.reflect.Main
```

На Windows замість `./mvnw` — `mvnw.cmd`. Встановлювати Maven не потрібно: wrapper завантажить його під час першого запуску. В IntelliJ можна просто натиснути ▶ біля `main`.

## Тести

```bash
./mvnw test                         # усі етапи
./mvnw test -Dgroups=stage1         # лише один етап: stage1, stage2, stage3, stage4, stage5
./mvnw test -Dgroups=stage1,stage2  # кілька етапів
```

Етапи, які ви ще не почали, падають з `UnsupportedOperationException: TODO` — так і має бути. Етап готовий, коли його тести зелені і програма друкує рівно очікуваний вивід із завдання.

> Анотації (`@Test`, `@JsonName`, `@Cacheable` тощо) вже оголошені, але **без** `@Retention` і `@Target` — додайте їх самі. Поки їх немає, рефлексія анотацій не бачить, і тести це покажуть.
