# Lab 07: Annotations and Reflection

The task text is on the course site. This project contains everything you would otherwise copy from it.

## What is inside

| File | Status |
| --- | --- |
| `Main.java` | given: uncomment the `STAGE` blocks one by one |
| `plugins/Plugin` | given, do not change |
| `testing/*`, `json/*`, `plugins/PluginInfo`, `plugins/PluginRegistry`, `proxy/*` | **yours**: replace every `throw new UnsupportedOperationException("TODO")` |
| `src/test/java/...` | tests for the stages |

## Opening the project

IntelliJ IDEA: **File → Open** → select this folder (the one with `pom.xml`). JDK 17 or newer.

## Running

```bash
./mvnw compile exec:java -Dexec.mainClass=pl.mini.reflect.Main
```

On Windows use `mvnw.cmd` instead of `./mvnw`. You do not need to install Maven: the wrapper downloads it on the first run. In IntelliJ you can simply press ▶ next to `main`.

## Tests

```bash
./mvnw test                         # all stages
./mvnw test -Dgroups=stage1         # only one stage: stage1, stage2, stage3, stage4, stage5
./mvnw test -Dgroups=stage1,stage2  # several stages
```

Stages you have not started yet fail with `UnsupportedOperationException: TODO` — that is expected. A stage is done when its tests are green and the program prints exactly the expected output from the task.

> The annotations (`@Test`, `@JsonName`, `@Cacheable` etc.) are already declared, but **without** `@Retention` and `@Target` — add them yourself. Until you do, reflection does not see the annotations, and the tests will show it.
