# Lab 01: Environment, Git and the First Program

The goal of this lab is to set up the environment and learn Git, so you create the project yourself. Only helper files are here.

## What is inside

| File | Status |
| --- | --- |
| `sample.txt` | the sample text from stage 2 |
| `WordStats.java` | **yours**: a skeleton that reads standard input |
| `CheckWordStats.java` | a checker for stages 2 and 3 |

## How to use

Copy these files into the `lab01/` folder of your repository (stage 1). After stage 2 run from that folder:

```bash
java WordStats.java < sample.txt
java CheckWordStats.java stage2
java CheckWordStats.java          # stages 2 and 3
```

Java 21 is required. The checker only gives hints: the Git history (commits, the branch, the merge, the tag) is graded too, and it does not see that.
