import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * Checks WordStats.java from the same folder (stages 2 and 3).
 *
 *   java CheckWordStats.java            all checks
 *   java CheckWordStats.java stage2     only stage 2 (or stage3)
 *
 * Each check runs `java WordStats.java` as a separate process, feeds text to standard input and compares the output with the task.
 */
public class CheckWordStats {

    record Result(int exitCode, String out, String err) { }

    static int passed, failed;

    public static void main(String[] args) throws Exception {
        Set<String> only = new HashSet<>(Arrays.asList(args));
        if (!Files.exists(Path.of("WordStats.java"))) {
            System.out.println("No WordStats.java in the current folder: run the checker from the lab01 folder.");
            System.exit(2);
        }
        String sample = Files.readString(Path.of("sample.txt"), StandardCharsets.UTF_8);

        if (only.isEmpty() || only.contains("stage2")) {
            System.out.println("== stage2 ==");
            expect("sample.txt", run(sample), """
                    Lines: 3
                    Words: 15
                    Characters: 80
                    Longest word: programming
                    """);
            expect("empty input", run(""), """
                    Lines: 0
                    Words: 0
                    Characters: 0
                    Longest word: -
                    """);
            expect("punctuation and several spaces", run("(hi)   there!\n\"ok\".\n"), """
                    Lines: 2
                    Words: 3
                    Characters: 18
                    Longest word: there
                    """);
            expect("the first of the longest words", run("abc xyz\nqwe\n"), """
                    Lines: 2
                    Words: 3
                    Characters: 10
                    Longest word: abc
                    """);
        }

        if (only.isEmpty() || only.contains("stage3")) {
            System.out.println("== stage3 ==");
            expect("--top 2 < sample.txt", run(sample, "--top", "2"), """
                    Lines: 3
                    Words: 15
                    Characters: 80
                    Longest word: programming
                    Top-2:
                      java     2
                      jvm      2
                    """);
            expect("--top 3 (case and equal frequencies)", run("B a b, A! c b\n", "--top", "3"), """
                    Lines: 1
                    Words: 6
                    Characters: 13
                    Longest word: B
                    Top-3:
                      b        3
                      a        2
                      c        1
                    """);
            expectExit("--top abc", run("x\n", "--top", "abc"), 1);
            expectExit("--top (no number)", run("x\n", "--top"), 1);
            expectExit("--unknown", run("x\n", "--unknown"), 1);
        }

        System.out.printf("%nPassed: %d, failed: %d%n", passed, failed);
        System.exit(failed == 0 ? 0 : 1);
    }

    static Result run(String stdin, String... args) throws Exception {
        String java = ProcessHandle.current().info().command().orElse("java");
        List<String> cmd = new ArrayList<>(List.of(java, "-Dfile.encoding=UTF-8", "-Dstdout.encoding=UTF-8", "-Dstderr.encoding=UTF-8", "WordStats.java"));
        cmd.addAll(Arrays.asList(args));
        Process p = new ProcessBuilder(cmd).start();
        try (OutputStream in = p.getOutputStream()) {
            in.write(stdin.getBytes(StandardCharsets.UTF_8));
        }
        var out = new ByteArrayOutputStream();
        var err = new ByteArrayOutputStream();
        Thread t1 = Thread.ofPlatform().start(() -> copy(p.getInputStream(), out));
        Thread t2 = Thread.ofPlatform().start(() -> copy(p.getErrorStream(), err));
        if (!p.waitFor(30, TimeUnit.SECONDS)) { p.destroyForcibly(); throw new IllegalStateException("timeout"); }
        t1.join();
        t2.join();
        return new Result(p.exitValue(), out.toString(StandardCharsets.UTF_8).replace("\r\n", "\n"), err.toString(StandardCharsets.UTF_8));
    }

    static void copy(InputStream in, OutputStream out) {
        try { in.transferTo(out); } catch (IOException e) { throw new UncheckedIOException(e); }
    }

    static void expect(String name, Result r, String expected) {
        if (r.exitCode() == 0 && r.out().equals(expected)) { ok(name); return; }
        fail(name);
        if (r.exitCode() != 0) System.out.println("    exit code " + r.exitCode() + "\n    " + r.err().strip().replace("\n", "\n    "));
        String[] e = expected.split("\n", -1), o = r.out().split("\n", -1);
        for (int i = 0; i < Math.max(e.length, o.length); i++) {
            String a = i < e.length ? e[i] : "<->", b = i < o.length ? o[i] : "<->";
            if (!a.equals(b)) System.out.printf("    line %d: expected \"%s\", got \"%s\"%n", i + 1, a, b);
        }
    }

    static void expectExit(String name, Result r, int code) {
        if (r.exitCode() == code && !r.err().isBlank()) { ok(name); return; }
        fail(name);
        System.out.println("    expected exit code " + code + " + System.err; got: " + r.exitCode()
                + (r.err().isBlank() ? ", System.err is empty" : ""));
    }

    static void ok(String name) { passed++; System.out.println("  ✓ " + name); }
    static void fail(String name) { failed++; System.out.println("  ✗ " + name); }
}
