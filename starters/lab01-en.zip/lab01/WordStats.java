import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

// Stage 2: no package, no collections and no Stream API — only arrays, String, StringBuilder and loops.
public class WordStats {
    public static void main(String[] args) throws IOException {
        var in = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        String line;
        while ((line = in.readLine()) != null) {
            // TODO (stage 2): count lines, words, characters and the longest word
        }
        // TODO (stage 2): print the statistics in the format from the task
    }
}
