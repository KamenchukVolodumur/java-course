import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

// Етап 2: без пакета, без колекцій і Stream API — лише масиви, String, StringBuilder і цикли.
public class WordStats {
    public static void main(String[] args) throws IOException {
        var in = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        String line;
        while ((line = in.readLine()) != null) {
            // TODO (stage 2): рахуйте рядки, слова, символи і найдовше слово
        }
        // TODO (stage 2): надрукуйте статистику у форматі із завдання
    }
}
