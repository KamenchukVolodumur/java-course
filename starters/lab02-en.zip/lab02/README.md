# Lab 02: Maven, Unit Tests and a Command-Line Application

You create the multi-module project structure (stage 1) yourself: it is part of the task. Only the Maven Wrapper, the data and the checks are here.

## What is inside

| File | Status |
| --- | --- |
| `mvnw`, `mvnw.cmd`, `.mvn/` | the Maven Wrapper: you do not need to install Maven |
| `.gitignore`, `data.txt` | given, do not change |
| `stats-core/src/test/.../StatisticsSpecTest` | the check of stage 2 (placed where your `stats-core` module will be) |
| `CheckCli.java` | the check of stages 4–5 (runs the built JAR) |

## Opening the project

IntelliJ IDEA: **File → Open** → select this folder (the one with `pom.xml`). JDK 17 or newer.

## How to use

Unpack the contents into the `lab02/` folder of your repository and create `pom.xml` and the `stats-core` and `stats-cli` modules next to them, as in the task. Then:

```bash
./mvnw verify                        # build and all tests (on Windows: mvnw.cmd)
./mvnw -pl stats-core test -Dtest=StatisticsSpecTest
java CheckCli.java                   # after stage 5
```

`StatisticsSpecTest` does not count towards the minimum of 12 tests of stage 3: write your own tests in a separate `StatisticsTest`.
