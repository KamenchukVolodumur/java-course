# Лабораторна 02: Maven, модульні тести та консольний застосунок

Структуру багатомодульного проєкту (етап 1) ви створюєте самі: це частина завдання. Тут лише Maven Wrapper, дані й перевірки.

## Що всередині

| Файл | Статус |
| --- | --- |
| `mvnw`, `mvnw.cmd`, `.mvn/` | Maven Wrapper: встановлювати Maven не потрібно |
| `.gitignore`, `data.txt` | надано, не змінюйте |
| `stats-core/src/test/.../StatisticsSpecTest` | перевірка етапу 2 (лежить там, де буде ваш модуль `stats-core`) |
| `CheckCli.java` | перевірка етапів 4–5 (запускає зібраний JAR) |

## Як відкрити

IntelliJ IDEA: **File → Open** → оберіть цю папку (ту, де лежить `pom.xml`). JDK 17 або новіший.

## Як користуватися

Розпакуйте вміст у папку `lab02/` репозиторію і створіть поруч `pom.xml` та модулі `stats-core` і `stats-cli`, як у завданні. Потім:

```bash
./mvnw verify                        # збірка і всі тести (на Windows: mvnw.cmd)
./mvnw -pl stats-core test -Dtest=StatisticsSpecTest
java CheckCli.java                   # після етапу 5
```

`StatisticsSpecTest` не зараховується в мінімум 12 тестів етапу 3: свої тести напишіть в окремому `StatisticsTest`.
