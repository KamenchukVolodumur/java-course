package pl.mini.stats;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Перевірка викладача для етапу 2. Це НЕ заміна вашого StatisticsTest (етап 3): його ви пишете самі.
 */
@Tag("stage2")
class StatisticsSpecTest {

    private static final double EPS = 1e-9;
    private final double[] data = {12.5, 7.0, 3.5, 10, 2.0};

    @Test
    void basicStatistics() {
        assertEquals(7.0, Statistics.mean(data), EPS);
        assertEquals(7.0, Statistics.median(data), EPS);
        assertEquals(19.125, Statistics.variance(data), EPS);
        assertEquals(Math.sqrt(19.125), Statistics.stdDev(data), EPS);
        assertArrayEquals(new double[]{2.0, 12.5}, Statistics.minMax(data), EPS);
    }

    @Test
    void medianOfEvenCount() {
        assertEquals(2.5, Statistics.median(new double[]{4, 1, 3, 2}), EPS);
    }

    @Test
    void percentileInterpolatesLinearly() {
        assertEquals(11.5, Statistics.percentile(data, 90), EPS);
        assertEquals(3.5, Statistics.percentile(data, 25), EPS);
        assertEquals(2.0, Statistics.percentile(data, 0), EPS);
        assertEquals(12.5, Statistics.percentile(data, 100), EPS);
        assertEquals(5.0, Statistics.percentile(new double[]{5}, 37), EPS);
    }

    @Test
    void normalizeScalesToZeroOne() {
        assertArrayEquals(new double[]{0, 0.5, 1}, Statistics.normalize(new double[]{-1, 0, 1}), EPS);
        assertArrayEquals(new double[]{0, 0, 0}, Statistics.normalize(new double[]{4, 4, 4}), EPS);
    }

    @Test
    void inputIsNotModified() {
        double[] copy = data.clone();
        Statistics.median(data);
        Statistics.percentile(data, 50);
        Statistics.normalize(data);
        assertArrayEquals(copy, data);
    }

    @Test
    void nullAndEmptyAreRejected() {
        NullPointerException npe = assertThrows(NullPointerException.class, () -> Statistics.mean(null));
        assertEquals("data", npe.getMessage());
        IllegalArgumentException iae = assertThrows(IllegalArgumentException.class, () -> Statistics.median(new double[0]));
        assertEquals("порожній масив", iae.getMessage());
    }

    @Test
    void varianceNeedsTwoElements() {
        assertThrows(IllegalArgumentException.class, () -> Statistics.variance(new double[]{1}));
        assertThrows(IllegalArgumentException.class, () -> Statistics.stdDev(new double[]{1}));
    }

    @Test
    void percentileOutsideRangeIsRejected() {
        assertThrows(IllegalArgumentException.class, () -> Statistics.percentile(data, -0.1));
        assertThrows(IllegalArgumentException.class, () -> Statistics.percentile(data, 100.1));
    }
}
