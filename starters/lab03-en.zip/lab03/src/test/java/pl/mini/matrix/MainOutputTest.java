package pl.mini.matrix;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import java.util.Locale;

import static pl.mini.testkit.Console.assertPrints;

/** Runs the same code as the STAGE blocks in Main and compares the output with the task. */
class MainOutputTest {

    private static Matrix sampleDense() {
        Matrix d = new DenseMatrix(2, 3);
        d.set(0, 0, 1); d.set(0, 2, 2); d.set(1, 1, 3);
        return d;
    }

    private static SparseMatrix sampleSparse() {
        SparseMatrix s = new SparseMatrix(2, 3);
        s.set(0, 0, 1); s.set(0, 2, 2); s.set(1, 1, 3);
        s.set(1, 0, 5); s.set(1, 0, 0);
        return s;
    }

    @Test
    @Tag("stage1")
    void stage1() {
        assertPrints("""
                [1.00, 0.00, 2.00]
                [0.00, 3.00, 0.00]
                2x3, nonzero=3
                OK: dimensions must be positive: 0x2
                OK: index (2, 0) is outside the 2x3 matrix
                """, () -> {
            Matrix d = sampleDense();
            System.out.println(d);
            SparseMatrix s = sampleSparse();
            System.out.println(s.getRows() + "x" + s.getColumns() + ", nonzero=" + s.nonZeroCount());
            try { new DenseMatrix(0, 2); }
            catch (IllegalArgumentException e) { System.out.println("OK: " + e.getMessage()); }
            try { d.get(2, 0); }
            catch (IndexOutOfBoundsException e) { System.out.println("OK: " + e.getMessage()); }
        });
    }

    @Test
    @Tag("stage2")
    void stage2() {
        assertPrints("""
                [1.00, 0.00]
                [0.00, 3.00]
                [2.00, 0.00]
                norm=3.7417
                true true
                [1.00, 0.00, 0.00]
                [0.00, 1.00, 0.00]
                [0.00, 0.00, 1.00]
                OK: identity: the 2x3 matrix is not square
                """, () -> {
            Matrix d = sampleDense();
            SparseMatrix s = sampleSparse();
            System.out.println(d.transpose());
            System.out.printf(Locale.ROOT, "norm=%.4f%n", d.norm());
            System.out.println(d.equals(s) + " " + (d.hashCode() == s.hashCode()));
            Matrix id = new SparseMatrix(3, 3);
            id.identity();
            System.out.println(id);
            try { d.identity(); }
            catch (IllegalStateException e) { System.out.println("OK: " + e.getMessage()); }
        });
    }

    @Test
    @Tag("stage3")
    void stage3() {
        assertPrints("""
                [1.00, 3.00]
                [4.00, 4.00]
                [2.00, 1.00]
                [4.00, 3.00]
                SparseMatrix
                [0.50, 1.00]
                [1.50, 2.00]
                OK: multiply: 2x3 * 2x2
                """, () -> {
            Matrix d = sampleDense();
            Matrix a = new DenseMatrix(2, 2);
            a.set(0, 0, 1); a.set(0, 1, 2); a.set(1, 0, 3); a.set(1, 1, 4);
            Matrix b = new SparseMatrix(2, 2);
            b.set(0, 1, 1); b.set(1, 0, 1);
            System.out.println(a.add(b));
            System.out.println(a.multiply(b));
            System.out.println(b.multiply(a).getClass().getSimpleName());
            System.out.println(a.scale(0.5));
            try { d.multiply(a); }
            catch (IllegalArgumentException e) { System.out.println("OK: " + e.getMessage()); }
        });
    }

    @Test
    @Tag("stage4")
    void stage4() {
        assertPrints("""
                [0.60, -0.70]
                [-0.20, 0.40]
                true
                """, () -> {
            Matrix m = new DenseMatrix(2, 2);
            m.set(0, 0, 4); m.set(0, 1, 7); m.set(1, 0, 2); m.set(1, 1, 6);
            Matrix inv = MatrixAlgorithms.pseudoInverse(m, 1000);
            System.out.println(inv);
            Matrix i2 = new DenseMatrix(2, 2);
            i2.identity();
            System.out.println(m.multiply(inv).subtract(i2).norm() < 1e-6);
        });
    }
}
