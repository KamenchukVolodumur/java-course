# Лабораторна 09: TCP-чат з погодою

Текст завдання — на сайті курсу. У цьому проєкті є все, що інакше довелося б копіювати звідти.

## Що всередині

| Файл | Статус |
| --- | --- |
| `Main.java` | надано: розкоментовуйте блоки `STAGE` по черзі |
| `Message`, `ProtocolException`, `WeatherProvider` | надано, не змінюйте |
| `MessageCodec`, `ChatServer`, `ChatClient`, `OpenMeteoProvider` | **ваше**: замініть кожен `throw new UnsupportedOperationException("TODO")` |
| `src/test/java/...` | тести до етапів |

## Як відкрити

IntelliJ IDEA: **File → Open** → оберіть цю папку (ту, де лежить `pom.xml`). JDK 21 або новіший.

## Запуск

```bash
./mvnw compile exec:java -Dexec.mainClass=pl.mini.chat.Main
```

На Windows замість `./mvnw` — `mvnw.cmd`. Встановлювати Maven не потрібно: wrapper завантажить його під час першого запуску. В IntelliJ можна просто натиснути ▶ біля `main`.

## Тести

```bash
./mvnw test                         # усі етапи
./mvnw test -Dgroups=stage1         # лише один етап: stage1, stage2, stage3, stage4, stage5
./mvnw test -Dgroups=stage1,stage2  # кілька етапів
```

Етапи, які ви ще не почали, падають з `UnsupportedOperationException: TODO` — так і має бути. Етап готовий, коли його тести зелені і програма друкує рівно очікуваний вивід із завдання.

> Jackson уже додано в `pom.xml`. Анотації `@JsonTypeInfo`/`@JsonSubTypes` на `Message` додайте самі (або напишіть власний кодек). Клас для обслуговування одного клієнта (`ClientHandler`) створіть самостійно.
>
> Тести етапів 2–5 запускають сервер на вільному порту з підробним `WeatherProvider`, тож інтернет для них не потрібен. `OpenMeteoProvider` перевірте вручну.
