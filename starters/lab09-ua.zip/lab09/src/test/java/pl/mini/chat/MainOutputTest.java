package pl.mini.chat;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import pl.mini.chat.Message.*;
import pl.mini.chat.Message.Error;

import java.time.Duration;
import java.util.concurrent.CompletableFuture;

import static pl.mini.testkit.Console.assertPrints;

/** The whole scenario of Main (stages 2–5 together), as in the task. */
@Timeout(20)
class MainOutputTest {

    @Test
    @Tag("stage5")
    void fullScenario() {
        assertPrints("""
                Info[text=вітаємо, %s! онлайн: %d]
                Info[text=вітаємо, %s! онлайн: %d]
                Info[text=%s приєднався]
                Say[user=ann, text=привіт]
                Info[text=Варшава: 12.5°C]
                Error[reason=немає даних для %s]
                Error[reason=ім'я %s зайняте]
                Info[text=%s вийшов]
                тиша: true
                """.formatted("ann", 1, "bob", 2, "bob", "Атлантида", "ann", "bob"), () -> {
            WeatherProvider fake = city -> CompletableFuture.completedFuture(
                    city.equals("Варшава") ? 12.5 : Double.NaN);
            try (ChatServer server = new ChatServer(0, fake)) {
                server.start();
                try (ChatClient ann = new ChatClient("localhost", server.port());
                     ChatClient bob = new ChatClient("localhost", server.port())) {
                    ann.send(new Join("ann"));
                    System.out.println(ann.receive());
                    bob.send(new Join("bob"));
                    System.out.println(bob.receive());
                    System.out.println(ann.receive());
                    ann.send(new Say("ann", "привіт"));
                    System.out.println(bob.receive());
                    bob.send(new Say("bob", "/weather Варшава"));
                    System.out.println(bob.receive());
                    bob.send(new Say("bob", "/weather Атлантида"));
                    System.out.println(bob.receive());
                    try (ChatClient impostor = new ChatClient("localhost", server.port())) {
                        impostor.send(new Join("ann"));
                        System.out.println(impostor.receive());
                    }
                    bob.send(new Leave("bob"));
                    System.out.println(ann.receive());
                    System.out.println("тиша: " + ann.poll(Duration.ofMillis(300)).isEmpty());
                }
            }
        });
    }
}
