# Lab 10: Layered Architecture, JDBC and Mockito

The task text is on the course site. This project contains everything you would otherwise copy from it.

## What is inside

| File | Status |
| --- | --- |
| `schema.sql`, `logback.xml`, `Client`, `ClientRepository`, `*Exception` | given, do not change |
| `Pesel`, `Database`, `JdbcClientRepository`, `ClientService` | **yours**: replace every `throw new UnsupportedOperationException("TODO")` |
| `ClientServiceTest` | **yours**: the Mockito tests (stage 5), the first one is already written |
| `src/test/java/...` | tests for the stages |

## Opening the project

IntelliJ IDEA: **File → Open** → select this folder (the one with `pom.xml`). JDK 17 or newer.

## Tests

```bash
./mvnw test                         # all stages
./mvnw test -Dgroups=stage1         # only one stage: stage1, stage2, stage3, stage4, stage5
./mvnw test -Dgroups=stage1,stage2  # several stages
```

Stages you have not started yet fail with `UnsupportedOperationException: TODO` — that is expected. A stage is done when its tests are green and the program prints exactly the expected output from the task.

> The integration tests (`*IT`, an H2 database) run with `./mvnw verify`, not `./mvnw test`: `./mvnw verify -Dgroups=stage3`. The unit tests (`*Test`) run with `./mvnw test`.
>
> Stage 5 is **your** tests in `ClientServiceTest`: four of them fail with `TODO` for now. The code of this lab will be needed in lab 12.
