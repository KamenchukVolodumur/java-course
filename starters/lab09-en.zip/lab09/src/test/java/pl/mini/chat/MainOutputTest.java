package pl.mini.chat;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import pl.mini.chat.Message.*;
import pl.mini.chat.Message.Error;

import java.time.Duration;
import java.util.concurrent.CompletableFuture;

import static pl.mini.testkit.Console.assertPrints;

/** The whole scenario of Main (stages 2–5 together), as in the task. */
@Timeout(20)
class MainOutputTest {

    @Test
    @Tag("stage5")
    void fullScenario() {
        assertPrints("""
                Info[text=welcome, %s! online: %d]
                Info[text=welcome, %s! online: %d]
                Info[text=%s joined]
                Say[user=ann, text=hi]
                Info[text=Warsaw: 12.5°C]
                Error[reason=no data for %s]
                Error[reason=name %s is taken]
                Info[text=%s left]
                silence: true
                """.formatted("ann", 1, "bob", 2, "bob", "Atlantis", "ann", "bob"), () -> {
            WeatherProvider fake = city -> CompletableFuture.completedFuture(
                    city.equals("Warsaw") ? 12.5 : Double.NaN);
            try (ChatServer server = new ChatServer(0, fake)) {
                server.start();
                try (ChatClient ann = new ChatClient("localhost", server.port());
                     ChatClient bob = new ChatClient("localhost", server.port())) {
                    ann.send(new Join("ann"));
                    System.out.println(ann.receive());
                    bob.send(new Join("bob"));
                    System.out.println(bob.receive());
                    System.out.println(ann.receive());
                    ann.send(new Say("ann", "hi"));
                    System.out.println(bob.receive());
                    bob.send(new Say("bob", "/weather Warsaw"));
                    System.out.println(bob.receive());
                    bob.send(new Say("bob", "/weather Atlantis"));
                    System.out.println(bob.receive());
                    try (ChatClient impostor = new ChatClient("localhost", server.port())) {
                        impostor.send(new Join("ann"));
                        System.out.println(impostor.receive());
                    }
                    bob.send(new Leave("bob"));
                    System.out.println(ann.receive());
                    System.out.println("silence: " + ann.poll(Duration.ofMillis(300)).isEmpty());
                }
            }
        });
    }
}
